#' @title resallele

#' @param a1 allele 1 in classical format with delimiters "DPB1*550:01"
#' @usage resallele("DPB1*550:01")
#' @examples data(dpb1)
#' @examples a1<-"DPB1*550:01"
#' @examples resallele(a1)


resallele<-function(a1){
	  
	#install require R packages if necessary and load them
  	if(!require(dplyr)){
    		install.packages("dplyr")
    		library(dplyr)
  			}
	#conditional stop type of format
	
	if(!is.character(a1)){
		stop('"allele 1" need to be in format "DPB1*01:01"')}

	#allele selection
	dpb1%>%filter(allele1 == a1)->selection

	#conditional stop on allele result
	nb = nrow(selection)

	if(nb == 0){
		stop('the allele is not present in the database')} 
	
	print("DPB1-Grantham distances for allele:")
	print (a1)
	result<-summary(selection$distance)
	result
} 
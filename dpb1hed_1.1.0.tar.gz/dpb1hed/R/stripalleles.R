#' @title stripalleles

#' @param a1 allele 1 in classical format with delimiters "DPB1*550:01"
#' @param a2 allele 2 in classical format with delimiters "DPB1*55:01"
#' @usage stripalleles("DPB1*550:01","DPB1*55:01")
#' @examples data(dpb1)
#' @examples a1<-"DPB1*550:01"
#' @examples a2<-"DPB1*55:01"
#' @examples stripalleles(a1,a2)





stripalleles<-function(a1,a2){

	#install require R packages if necessary and load them
  	if(!require(dplyr)){
    		install.packages("dplyr")
    		library(dplyr)
  			}
	if(!require(ggplot2)){
    		install.packages("ggplot2")
    		library(ggplot2)
  			}

	#conditional stop type of format

	if(!is.character(a1)){
		stop('"allele 1" need to be in format "DPB1*01:01"')}
	if(!is.character(a2)){
		stop('"allele 2" need to be in format "DPB1*01:01"')}


	dpb1%>%
	dplyr::rename(allele = "allele1")%>%
	filter(allele == "DPB1*01:01" | allele == "DPB1*05:01")%>%
	ggplot(.,aes(x=allele,y=distance,color=allele))+
	geom_violin(trim=FALSE,color="grey60")+
	geom_jitter(size=2,alpha=0.3)+
	theme_minimal()+
	theme(text = element_text(size = 16))+
	theme(legend.position = "none")+
	xlab("DPB1 alleles")+
	ylab("Grantham distances")+
	ggtitle("HLA-DPB1 Exon 2\nPatterns of HED (Grantham)") +
	stat_summary(fun.data=mean_sdl, mult=1, geom="pointrange", color="grey60",size=1)+
	scale_color_manual(values=c("#E69F00", "#56B4E9"))

}

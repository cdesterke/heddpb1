#' @title heddpb1

#' @param a1 allele 1 in classical format with delimiters "DPB1*550:01"
#' @param a2 allele 2 in classical format with delimiters "DPB1*55:01"
#' @usage heddpb1("DPB1*550:01","DPB1*55:01")
#' @examples data(dpb1)
#' @examples a1<-"DPB1*550:01"
#' @examples a2<-"DPB1*55:01"
#' @examples heddpb1(a1,a2)



heddpb1<-function(a1,a2){

	#install require R packages if necessary and load them
  	if(!require(dplyr)){
    		install.packages("dplyr")
    		library(dplyr)
  			}

	#conditional stop type of format

	if(!is.character(a1)){
		stop('"allele 1" need to be in format "DPB1*01:01"')}
	if(!is.character(a2)){
		stop('"allele 2" need to be in format "DPB1*01:01"')}


	#allele selection
	dpb1%>%filter(allele1 == a1)%>%filter(allele2 == a2)->selection

	#conditional stop on allele result
	nb = nrow(selection)

	if(nb != 1){
		stop('one of the allele is not present in the database')}


	#print on screen
	print("HED Grantham distance DPB1-Ex2: ")

	#create and return list of results
	l1<-selection$allele1
	l2<-selection$allele2
	l3<-selection$distance
	l<-list(allele1=l1,allele2=l2,HED.Grantham.distance=l3)
	l
}




